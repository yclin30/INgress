package com.yclin.ingressbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngressBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(IngressBackendApplication.class, args);
    }

}
