package com.yclin.ingressbackend.entity.enums;

public enum UserGender {
    MALE,
    FEMALE,
    OTHER,
    PREFER_NOT_TO_SAY
}