package com.yclin.ingressbackend.entity.enums;

public enum UserRole {
    ROLE_USER,
    ROLE_ADMIN
}