package com.yclin.ingressbackend.dto.auth;

import com.yclin.ingressbackend.entity.enums.UserGender;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegisterRequest {
    private String username;
    private String email;
    private String password;
    private UserGender gender; // 可选
    private String introduction; // 可选
}